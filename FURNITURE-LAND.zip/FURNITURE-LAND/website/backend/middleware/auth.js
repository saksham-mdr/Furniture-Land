const { Next } = require("react-bootstrap/esm/PageItem");
const ErrorHandler = require("../utils/errorhandler");
const catchAsyncErrors = require("./catchAsyncErrors");
const jwt = require("jsonwebtoken");
const userModels = require("../models/userModels");
exports.isAuthenticatedUser= catchAsyncErrors( async(req,res,net)=>{
    const {token }=req.cookies;
   if(!token){
       return next(new ErrorHandler("please login to access this resource",401))
   }
   const decoderData =jwt.verify(token,process.env.JWT_SECRET);
   req.user = await userModels.findById(decoderData.id);
   next();
});