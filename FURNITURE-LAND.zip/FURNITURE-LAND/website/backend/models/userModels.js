
const validator =require("validator");
const mongoose= require("mongoose");
const bcrypt = require("bcryptjs");
const jwt=require("jsonwebtoken");
const userSchema = new mongoose.Schema({
    name:{
        type:String,
        required:[true,"please Enter your Name"],
        maxLength:[30,"name cannot exceed 30 charecter"],
        minLength:[4,"name cannot be less then 4 charecter"]
        
    },
    email:{
        type:String,
        required:[true,"please Enter your Email"],
        unique:true,
        validate:[validator.isEmail,"please enter valid email"]
    },
    password:
    {
        type:String,
        required:[true,"please Enter your Password"],
        minLength:[8,"password should be greater then 8 charecters"],
        select:false,

    },
avatar:
        {
          public_id:{
              type:String,
              require:true
          },
          url:{
              type:String,
              required:true
          }
        },
        role:{
            type:String,
            default:"user",
        },

        resetPasswordToken:String,
        resetPasswordExpire:Date,
        
});
userSchema.pre("save",async function(next){

    if(!this.isModified("password")){
        next();
    }
    

    this.password = await bcrypt.hash(this.password,10)
});
//jwt token

userSchema.methods.getJWTToken = function(){
    return jwt.sign({id: this._id},process.env.JWT_SECRET,{
        expiresIn:process.env.JWT_EXPIRE,
    });
};

//Compare password
userSchema.methods.comparePassword = async function(enteredPassword){

    return await bcrypt.compare(enteredPassword,this.password);

}

module.exports =mongoose.model("User",userSchema);