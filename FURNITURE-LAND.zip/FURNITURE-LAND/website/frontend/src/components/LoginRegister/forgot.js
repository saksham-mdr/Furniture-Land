import React from 'react';
import './login.css';
const Forgot = () => {
    return (
        <div>
                    <div>
            <div className="wrapper">
    <form className="form-signup">       
      <h2 className="form-signup-heading">Please enter your Gmail id</h2>
      <input type="text" className="form-control" id='Id' name="useremail" placeholder="Gmail ID"    pattern=".+@gmail\.com" size="30" required autofocus="" />       
      <button className="btn btn-lg btn btn-dark btn-block" type="submit">Reset</button> 
    </form>
  </div>
        </div>
        </div>
    );
}

export default Forgot;
