import React from 'react';
import './login.css';
const Signup = () => {
    return (
        <div>
            <div className="wrapper">
    <form className="form-signup">       
      <h2 className="form-signup-heading">Please Register</h2>
      <input type="text" className="form-control" id='firstname'    name="userfname" placeholder="Firstname" required autofocus="" />
      <input type="text" className="form-control" id='lastname' name="userlname" placeholder="Lastname" required autofocus="" />
      <input type="text" className="form-control" id='Id' name="useremail" placeholder="Gmail ID"    pattern=".+@gmail\.com" size="30" required autofocus="" />
   
      <input type="number" className="form-control" id='number' name="usernumber" placeholder="Contact Number" maxlength="10" required autofocus="" />
      
      <input type="password" className="form-control" id='password' name="password" placeholder="Set A Password" required/>          
      <button className="btn btn-lg btn btn-dark btn-block" type="submit">Login</button> 
    </form>
  </div>
        </div>
    );
}

export default Signup;
