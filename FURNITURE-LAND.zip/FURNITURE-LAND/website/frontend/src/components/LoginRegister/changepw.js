import React from 'react';
import './login.css';
const Changepw = () => {
    return (
        <div>
                            <div>
            <div className="wrapper">
    <form className="form-signup">       
      <h2 className="form-signup-heading">Please enter new password</h2>
      <input type="password" className="form-control" id='password' name="password" placeholder="Set A Password" required/>     
      <input type="password" className="form-control" id='Npassword' name="password" placeholder="Set A Password" required/>        
      <button className="btn btn-lg btn btn-dark btn-block" type="submit">Reset</button> 
    </form>
  </div>
        </div>
        </div>
    );
}

export default Changepw;
