import React from 'react'
import './css/banner.css';
import {Outlet } from 'react-router-dom';
export default function Banner() {
  return (
    <div>
       <section  id="banner">
        <div className="containerf-fluid">
            <div className="containerf">
                <ul>
                    <a href="#sortbyCats"> <li> Categories </li></a>
                    <a href="#review"><li> Reviews  </li></a>
                    <a href="#lower"><li>Quick Links</li></a>
                </ul>
            </div>
        </div>
   </section>
   <Outlet/>
        </div>
  )
}
