import React from 'react'
import {Outlet } from 'react-router-dom';
import U1 from './image/cus1.png';
import U2 from './image/cus2.png';
import U3 from './image/cus3.png';
export default function Review() {
  return (
    <div>
        <section id="review">
        
        <h1>Reviews</h1>
        
        <div className="review-box-container">	
        <div className="review-box">
                <div className="box-top"> 
                    <div className="profile">
                        <div className= "profile-img">
                            <img src={U1}/> 
                        </div>
                        <div className= "name-user">
                            <p> Harry Wittek </p>
                        </div>
                    </div>
                </div>
                <div className="customer-comment">
                   <p> A great experience shopping from here. The only thing i would recommend is a delivery service in the long run. Otherwise, it's a 5 star from me! </p>
                </div>
            </div>

            <div className="review-box">
                <div className="box-top"> 
                    <div className="profile">
                        <div className= "profile-img">
                            <img src={U2}/> 
                        </div>
                        <div className= "name-user">
                            <p> Angela Beesly </p>
                        </div>
                    </div>
                </div>
                <div className="customer-comment">
                   <p> I can find most, if not all furnitures in this website. The seller have done a great job with the service as well as their prices. </p>
                </div>
            </div>

            
            <div className="review-box">
                <div className="box-top"> 
                    <div className="profile">
                        <div className= "profile-img">
                            <img src={U3}/> 
                        </div>
                        <div className= "name-user">
                            <p> Emilia Fischer </p>
                        </div>
                    </div>
                </div>
                <div className="customer-comment">
                   <p> Shopping from this website has been nothing but a good experience for me. The sellers are very friendly and make you feel very welcome. </p>
                </div>
            </div>
            
        </div>
        </section>
        <Outlet/>
    </div>
  )
}
