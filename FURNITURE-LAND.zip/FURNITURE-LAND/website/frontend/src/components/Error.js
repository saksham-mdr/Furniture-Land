import React from 'react'
import './css/Error.css'
export default function Error() {
  return (
    <div>
      <h1 className='error'> 
404 EROR     </h1> 
     </div>
  )
}
