import React from 'react';
import { Link } from 'react-router-dom';
import ReactStars from 'react-rating-stars-component';
import './css/product.css';





const Product = ({product}) => {

  
    
    const options={
        edit:false,
        color:"rgb(20,20,20,0.1)",
        activeColor:"tomato",
        size: window.innerWidth < 600 ? 20 : 25,
        
        value:product.ratings,
        isHalf:true,
    };
   
    if(product.category==="bedroom"){


   
        
    return (
        // <div>
        <div id="arrange"> 
        <div className="boxe">

        
                    <Link className="productCards" to={`/product/${product._id}`}>
                        <img src={product.images[0].url} alt={product.name}/>
                        <p>{product.name}</p>  
                        <div className="star">
                    <ReactStars {...options}/>
                    <span className='rev'>
                        ({product.numOfReviews}reviews)
                    </span>
                    </div>
                    <span>{`₹${product.price}`}</span>      
                    </Link>




        <div className="buy-btn">
                     <a href="productview" >Buy Now</a>
                    </div>
        </div> 
        </div>

        
    
        
    );
    
}}

export default Product;
