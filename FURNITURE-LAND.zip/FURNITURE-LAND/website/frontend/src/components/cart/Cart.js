import React from 'react';
import './cart.css';
const Cart = () => {
    return (
      <div>
        </div>
    );
}

export default Cart;
