import React from 'react';
import './css/hello.css'
const Hello = () => {
    return (
        <div className='HELLO'>
            <h5>KISHAN</h5>
        </div>
    );
}

export default Hello;
