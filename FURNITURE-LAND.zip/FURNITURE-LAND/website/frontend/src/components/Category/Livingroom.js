import React,{useEffect} from 'react'
import './csscat/categorys.css';
import Product from "../ProductLiving";


import bedroom from '../image/bedroom.svg';
import livingroom from '../image/livingroom.svg';
import dining from '../image/dining.svg';
import kitchen from '../image/kitchen.svg';
import office from '../image/office.svg';
import { BrowserRouter as Router,Routes,Outlet, Link } from "react-router-dom";
import MetaData from '../layout/MetaData';
import { Fragment } from 'react';
import { getProduct } from '../../actions/productAction';
import{useSelector,useDispatch} from "react-redux"
import Loader from '../layout/loader/loader';
import  {useAlert} from 'react-alert';
import {product,product2} from "./datas"


// to try with out backend



// const product ={
    
// name:"Bed",
// images:[{url:"https://cb2.scene7.com/is/image/CB2/DondraQueenBedSHS21_1x1/$web_pdp_main_carousel_md$/210203123041/dondra-teak-queen-bed.jpg"}],
// ratings:"2.5",
// numOfReviews:"300",
// price:"500",

// // numOfReviews=300,
// _id:"bed2"};
// const product2 ={
    
//     name:"Bed",
//     images:[{url:"https://static3.depositphotos.com/1004099/180/i/600/depositphotos_1809008-stock-photo-brown-wooden-bed-isolated-on.jpg"}],
//     price:"200",
//     ratings:"4.5",
//     category:"bedroom",
//     numOfReviews:"100",
//     _id:"bed3"};



const Livingroom = ()=>{
    const alert=useAlert()
    const dispatch=useDispatch();
    const{loading ,error,products,productsCount}=useSelector(
        (state)=>state.products
        );




// export default function Bedroom() {
 
//      const dispatch=useDispatch();

//     const{loading,error,products}=useSelector(state=>state.products)
    
    
    
    
    useEffect(() => {
   if (error){
       return alert.error("error");
   }


      dispatch(getProduct()); 
    }, [dispatch,error,alert]);

    useEffect(() => {
        window.scrollTo(0, 0)
      }, [])

  return (
    <div>
        <div className="moreCats " id="moreCats">
 
        <div className="categorys">
        <Link  to='/bedroom' className='a'>
      
        <div className="svgImg">
                    <img src={bedroom} className="small" alt="Bedroom" />
                    {/* style="width:50px" */}
                </div>
                <p className="ttl">Bedroom</p>
        </Link>
        </div>  

        <div className="categorys">
        <Link  to='/office' className='a'>
        <div className="svgImg"> 
                    <img src={office}  className="small" alt="Office" />
                </div>
                <p className="ttl">Office</p>
            </Link>
        </div>

        <div className="categorys">
    
        <Link  to='/kitchen' className='a'>
                <div className="svgImg">
                    <img src={kitchen}  className="small"  alt="Kitchen" /> 
                </div>
                <p className="ttl">Kitchen</p>
                </Link>
        </div>

        <div className="categorys">
       
        <Link  to='/dining' className='a'>
        <div className="svgImg">
                    <img src={dining }   className="small" alt="Dining" />
                </div>
                <p className="ttl">Dining</p>
            </Link>
        </div>

        <div className="categorys  active">
        <Link  to='/livingroom' className='a'>
        
                <div className="svgImg">
                    <img src={livingroom}  className="small" alt="Livingroom" />   
                    {/* style="width:50px" */}
                </div>
                <p className="ttl">Livingroom</p>
           </Link>
        </div>  
        
    </div>

    <Fragment>

    <div className="wrapall">
      
        
        

                  <div id="sorting" >
                
                      <form method="post">
                          <select name="sort">
                              <option value=" selected hidden">Sort By</option>
                              <option value="maxprice">Maximum Price</option>
                              <option value="minprice">Minimum Price</option>
                          </select>

                          <input type="submit" name="orderSearch" value="Sort"/>
                      </form>

                  </div> 

                  <div id="titled">
                      <h5> Living Category </h5>
                  </div>
        
                  {loading ? <Loader/>:(

                  
                    <div className='container' id="container">
                    

       {/* to use without backend */}


                    <Product product={product}/>
                   
                    <Product product={product2}/>
                   
                    <Product product={product}/>
                   
                   <Product product={product2}/>

       {/* to use without backend */}


                    
                    {products && products.map(product=>( 
                    <Product product={product}/>
                    ))}
                    
                 
                    </div>
                  )}
    
                    </div> 
                    
                    
     
        </Fragment>
        <Outlet/>

    </div>
  )
}
export default Livingroom;