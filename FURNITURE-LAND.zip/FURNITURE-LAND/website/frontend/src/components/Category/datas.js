


const product ={
    
    name:"BED",
    images:[{url:"https://cb2.scene7.com/is/image/CB2/DondraQueenBedSHS21_1x1/$web_pdp_main_carousel_md$/210203123041/dondra-teak-queen-bed.jpg"}],
    ratings:"2.5",
    numOfReviews:"300",
    price:"500",
    category:"bedroom",
    // numOfReviews=300,
    _id:"bed2"};


    const product2 ={
        
        name:"SOFA",
        images:[{url:"https://www.ulcdn.net/opt/www.ulcdn.net/images/products/77211/original/FNSF51WCCO3_-_main_1.jpg?1464079594"}],
        price:"200",
        ratings:"4.5",
        category:"living",
        numOfReviews:"100",
        _id:"living1"};


        const product3 ={
        
            name:"DINING-TABLE",
            images:[{url:"https://cdn.shopify.com/s/files/1/2660/5202/products/shopify-image_1dc33ede-2fe8-4db3-85a4-5b35aae92f36_1400x.jpg?v=1594930718"}],
            price:"700",
            ratings:"3.5",
            category:"dining",
            numOfReviews:"20",
            _id:"dining1"};




            const product4 ={
        
                name:"OFFICE-TABLE",
                images:[{url:"https://m.media-amazon.com/images/I/51RQWvkjeKL._SL1500_.jpg"}],
                price:"700",
                ratings:"2.5",
                category:"office",
                numOfReviews:"20",
                _id:"office1"};
    
                const product5 ={
        
                    name:"KITCHEN-TABLE",
                    images:[{url:"https://stylesatlife.com/wp-content/uploads/2020/01/15-Latest-Kitchen-Furniture-Designs-With-Pictures.jpg.webp"}],
                    price:"700",
                    ratings:"2.5",
                    category:"kitchen",
                    numOfReviews:"20",
                    _id:"kitchen1"};

        export{product,product2,product3,product4,product5};