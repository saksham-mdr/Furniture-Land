import React from 'react';
import './css/addproduct.css';

const Addproduct = () => {
  
    return (
        <div>
            <div class="containerAdd">
  <div class="add-product">
    <form>
      <div>
        <label>Product name:</label>
        <input type="text" placeholder="" />
      </div>
      
      <div>
        <label>Product description:</label>
        <textarea placeholder="Sample description..." rows="7" cols="50"></textarea>
      </div>

<div>
  <lable>Category:</lable><br></br>
  <select id="categoris" className='categories' name="category" default>
    <option value="0">Select Category:</option>
    <option value="bedroom">Bedroom</option>
    <option value="living">Livingroom</option>
    <option value="kitchen">Kitchen</option>
    <option value="dining">Dining</option>
    <option value="office">Office</option>
  </select>
</div>

      <div>
        <label>Location:</label>
        <input type="text" placeholder="location" />
      </div>
      <div>
        <label>Product image:</label>
        <input type="text" placeholder="" />
      </div>
      <div>
        <lable>Stock</lable>
        <input type="number" id="quantity" name="quantity" min="1" max="5"></input>
      </div>
      
      <div>
        <label>Product price:</label>
        <input type="number" id="quantity" name="quantity" min="1" max="5"/>
      </div>
      
      <button>Add</button>
    </form>
  </div>
  
</div>
        </div>
    );
}

export default Addproduct;
