import React from 'react';
import Carsole from 'react-material-ui-carousel';
import { productDetailsReducer } from '../../reducers/productReducer';

import'../css/productView.css';
import'./ProductDetails.css'
import {useSelector,useDispatch } from "react-redux"
import {getProductDetails} from "../../actions/productAction"


const ProductDetails = ({match}) => {

    const dispatch=useDispatch();

const{product,loading,error}=useSelector(
    (state)=>state.productDetails
    );

    // useEffect(() => {
    //    dispatch(getProductDetails(match.params.id));
    // }, [dispatch,match.params.id]);
	

    return (
<div className='ProductDetails'> 
<div>
    <Carsole>

        {

            product.images &&
            product.images.map((item, i)=>(
<img 
className='CarouselImage' 
key={item.url}
src={item.url}
alt={`${i} Slide`}

/>
            ))
        }
    </Carsole>
</div>
</div>
        
    );
}





export default ProductDetails;
