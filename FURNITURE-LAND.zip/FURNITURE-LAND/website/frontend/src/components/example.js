import React from 'react'

export default function example() {
  return (
    <div><h1>example</h1></div>
  )
}
