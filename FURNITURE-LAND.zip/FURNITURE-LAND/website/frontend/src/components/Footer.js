import React from 'react'
import Logo from './image/furniturelogo.png';
import {Outlet } from 'react-router-dom';
export default function Footer() {
  return (
    <div className="foot">
<footer id="lower">
            <div className="containers">
                <div className="rows show">
                    
                    <div className="co-1 co">
                        
                        <ul>
                            <li><p>Information</p></li>
                            <li><a href="footer/privacyPolicy">Privacy Policy</a></li>
                            <li><a href="footer/terms">Terms & Conditions</a></li>
                            <li><a href="Session/customer_signup">Become a Customer</a></li>
                            <li><a href="footer/about">About Us</a></li>
                        </ul>
                    </div>

                    <div className="co-2 co">
                        
                        <div className="img-box">
                            <a href="/"><img src={Logo} width="100%"/></a>
                            <br></br><br></br><br></br>
                            <p>A place where everything is special.<br></br>New & used marketplace.</p>
                        </div>

                    </div>


                    <div className="co-3 co">
                        
                        <ul>
                            <li><p>Quick Links</p></li>
                            <li><a href="#sortbyCats">Shop By Category</a></li>
                            <li><a href="Customer/shoppingCart">Add to Cart</a></li>
                            <li><a href="Session/trader_signup">Become a Trader</a></li>
                            <li><a href="Session/login">Sign In</a></li>
                        </ul>
                    </div>
                </div>


            <div className="rows hide">       

                <div className="co-1 co">
                    
                    <ul>
                    <li>
                        <p>Information</p></li>
                        <li><a href="footer/privacyPolicy">Privacy Policy</a></li>
                        <li><a href="footer/terms">Terms & Conditions</a></li>
                        <li><a href="Session/customer_signup">Become a Customer</a></li>
                        <li><a href="footer/about">About Us</a></li>
                    </ul>
                </div>
                
                <div className="co-3 co">
                    
                    <ul>
                        <li><p>Quick Links</p></li>
                        <li><a href="#sortbyCat">Shop By Category</a></li>
                        <li><a href="Customer/shoppingCart">Add to Cart</a></li>
                        <li><a href="Session/trader_signup">Become a Trader</a></li>
                        <li><a href="">Sign In</a></li>
                    </ul> 
                </div>
            </div>

            </div> 
            
        </footer>
            <div className="down">
                <a href="/"> Copyright &copy; 2022 FurnitureLand</a>
            </div> 
<Outlet/>
    </div>
  )
}
