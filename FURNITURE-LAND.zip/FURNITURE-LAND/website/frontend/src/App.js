// import logo from './logo.svg';
import './App.css';
import './components/css/nav.css';
import './components/css/banner.css';
import './components/css/body.css';
import './components/css/Carsole.css';
// import './components/css/shopbycategory.css';
// import './components/css/productView.css';
import './components/css/space.css';
import './components/css/review.css';
import './components/css/footer.css';


import MetaData from './components/layout/MetaData';


import bootstrap from'../node_modules/bootstrap/dist/css/bootstrap.min.css'
import Navbar from './components/Navbar';
import Banner from './components/Banner';
import Carsole from './components/Carsole';
import Productgrid from './components/Productgrid';
import Review from './components/Review';
import Fotter from './components/Footer';
import Error from './components/Error';
import Login from './components/LoginRegister/login';
import Signup from './components/LoginRegister/signup';
import Productview from './components/Productview';
import Shop from './components/Shops/Shop';
import Addproduct from './components/Addproduct';


// 
import Loader from './components/layout/loader/loader';
import Office from './components/Category/Office';
import Kitchen from './components/Category/Kitchen';
import Livingroom from './components/Category/Livingroom';
import Dining from './components/Category/Dining';
import Bedroom from './components/Category/Bedroom';

import ProductDetails from './components/product/ProductDetails.js';

import {BrowserRouter as Router,Routes ,Route,Navigate,Outlet } from 'react-router-dom';
import Home from './home/home';
import Hello from './components/hello';





function App() {
  return (

 <div>
   
  <MetaData title="Furniture Land"/> 
    <div className ="About head">
     <Navbar />
 
    </div>
    
<Router>
<Routes>

<Route path="/" exact element={<Home/>}/>
<Route path="*"  element={<Error />}/>
<Route path="/bedroom" element={<Bedroom/>}/>
<Route path="/Livingroom" element={<Livingroom/>}/>
<Route path='/office' element={<Office/>}/> 
<Route path="/dining" element={<Dining/>}/>
<Route path="/kitchen" element={<Kitchen/>}/>
<Route path="hello" element={<Hello/>}/>
<Route path="/addproduct" element={<Addproduct/>}/> 
<Route path="/kitchen" element={<Kitchen/>}/>
<Route path="/login" element={<Login/>}/>
<Route path="/signup" element={<Signup/>}/>
<Route path="/productview" element={<Productview/>}/>
<Route path="/product/:id" element={<ProductDetails/>}/>


</Routes>
</Router>


 

<div className='About'>


    <Router>
   
         {/* <Routes>
         <Route path="*"  element={<Navbar />}/>
         </Routes>  */}
        <Routes>
        {/* <Route path='/office' element={<Office/>}/>  */}
          {/* <Route path="/" exact element={<Banner />}/> */}
         </Routes>
        <Routes>  
    
          {/* <Route path="/" exact element={<Carsole />}/>  */}
       </Routes>
        <Routes> 
        {/* <Route path="/bedroom" element={<Bedroom/>}/> */}
          {/* <Route path="/" exact element={<Productgrid />}/> */}
       </Routes>
        <Routes> 
         
        {/* <Route path="/Livingroom" element={<Livingroom/>}/> */}
          {/* <Route path="/" exact element={<Review />}/> */}
       </Routes>
        <Routes>
        {/* <Route path="/dining" element={<Dining/>}/> */}
          {/* <Route path="/" exact element={<Fotter />}/> */}
          
        </Routes>

            <Routes>
                <Route path="/Shop" element={<Shop/>}/>

            </Routes> 
            <Routes>
             
            </Routes> 
         
     </Router>
     
    </div>

    
   <div className="About space">



     </div>


 </div>

   
  );
}

export default App;
